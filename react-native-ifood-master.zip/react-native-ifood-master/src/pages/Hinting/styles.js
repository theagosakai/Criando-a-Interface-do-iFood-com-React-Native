import styled from 'styled-components/native';

export const Container = styled.View`
  flex: 1;
  background: #FFF
`;

export const BackButton = styled.TouchableOpacity``;

export const ExportButton = styled.TouchableOpacity`
  margin-right: 10px
`;
const colorRed = '#FF5665';

export { colorRed };
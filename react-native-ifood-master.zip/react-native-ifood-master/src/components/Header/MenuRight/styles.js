import styled from 'styled-components/native';

export const Container = styled.View`
  margin-right: 15px
`;

export const Button = styled.TouchableOpacity`
  margin-left: 10px
`;